// JavaScript Document

function Guardar(){
	
	form.submit();
	return true;
	}
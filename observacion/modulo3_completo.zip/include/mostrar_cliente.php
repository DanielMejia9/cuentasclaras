<?php
if (isset($row["cod_clientes"])) 
{
	echo ('Nombre del Cliente'.$row['nom_empresa']);
	echo ('Direccion'.$row['dir_empresa']);
	echo ('Direccion'.$row['rif_empresa']);
	echo ('Direccion'.$row['cont_especial']);	
}else{
	
}
?>

<?php
//datos para establecer la conexion con la base de mysql.
mysql_connect('localhost','caracasw_uadmin',']5aLlaspW@qI')or die ('Ha fallado la conexión: '.mysql_error());
mysql_select_db('caracasw_admin')or die ('Error al seleccionar la Base de Datos: '.mysql_error());
?>

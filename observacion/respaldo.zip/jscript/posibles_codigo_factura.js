// JavaScript Document//i = 0;
//		i = i +1;
//		
//		
//		var v1 = document.getElementById("txtTota"+i).value;
//		var txtTota = "txtTota";
//		var f;
//		for(i=1; i<10; i++)
//		{
//		
//		var total = txtTota+i;
//		var colTotal = document.getElementById(total).value;
//		//alert("Valor"+total);
//		//alert("Valor : "+colTotal);
//		}


				
		
		//	if(colTotal!="")
//			{
//				
//				var subtotal = parseInt(colTotal);
//				subtotal = parseInt(subtotal);
//				
//				
//				//alert(subtotal);
//				
//			}

		
		
		
		//var subtotal = parseInt(colTotal);
		////////subtotal = parseInt(subtotal);
		///////////////document.getElementById("subTotal").value = subtotal	
		//subtotal = parseInt(subtotal);
		//document.getElementById("subTotal").value = subtotal	
		
		
		
		//var v2 = document.getElementById("txtTota"+j).value;
		//alert("Valor"+v2);

		
		//var subtotal = (parseInt(v1+i) + parseInt(v2+j));
		//subtotal = parseInt(subtotal);
		
		//document.getElementById("subTotal").value = subtotal

		
		
		
//		for(i=0; i<10; i++)
//		{
//			document.getElementById("txtTota"+i).value;
//			
//			alert(document.getElementById("txtTota"+i).value);
//			}




		
//		v1 = document.getElementById("txtTota1").value;
//		v2 = document.getElementById("txtTota2").value;
//		v3 = document.getElementById("txtTota3").value;
//		v4 = document.getElementById("txtTota4").value;
//		v5 = document.getElementById("txtTota5").value;
//		v6 = document.getElementById("txtTota6").value;
//		v7 = document.getElementById("txtTota7").value;
//		v8 = document.getElementById("txtTota8").value;
//		v9 = document.getElementById("txtTota9").value;
//		v10 = document.getElementById("txtTota10").value;

//+ parseInt(v3)+ parseInt(v4)+ parseInt(v5)+ parseInt(v6)+ parseInt(v7)+ parseInt(v8)+ parseInt(v9)+ parseInt(v10)
		
		//var subtotal = (parseInt(v1) + parseInt(v2));
		//subtotal = parseInt(subtotal);
		//document.getElementById("subTotal").value = subtotal
		
		
		
		
		
		
		
		
		
		
		//var v1,v2,v3,v4,v5,v6,v7,v8,v9;
//
//
//
//		
//		v1 = document.getElementById("txtTota1").value;
//		v2 = document.getElementById("txtTota2").value;
////		v3 = document.getElementById("txtTota3").value;
////		v4 = document.getElementById("txtTota4").value;
////		v5 = document.getElementById("txtTota5").value;
////		v6 = document.getElementById("txtTota6").value;
////		v7 = document.getElementById("txtTota7").value;
////		v8 = document.getElementById("txtTota8").value;
////		v9 = document.getElementById("txtTota9").value;
////		v10 = document.getElementById("txtTota10").value;
//
////+ parseInt(v3)+ parseInt(v4)+ parseInt(v5)+ parseInt(v6)+ parseInt(v7)+ parseInt(v8)+ parseInt(v9)+ parseInt(v10)
//		
//		var subtotal = (parseInt(v1) + parseInt(v2));
//		subtotal = parseInt(subtotal);
//		document.getElementById("subTotal").value = subtotal



//OTROASSSS
//	var tabla = document.getElementById("tablaFactura");
//	var fila = tabla.getElementsByTagName("tr");
//	var sum = new Array(fila.length);
//	var tot;
//	var total = 0;
//
//	for (i = 0; i < sum.length; i++)
//	{
//		sum[i] = 0;
//		for (i = 1, tot = fila.length - 1; i < tot; i++) {
//			if (idFila == i)
//			{
//				//total = 0;
//				celdas = fila[i].getElementsByTagName("td");
//				for (var j = 5, to = celdas.length - 1; j < to; j++) {
//					//total = 0;
//					textos = celdas[j].getElementsByTagName("input");
//					for (var t = 0, tota = textos.length; t < tota; t++) {
//						var num = parseInt(textos[t].value);
//						if (isNaN(num)) num = 0;
//						total += num;
//						sum[t - 2] += num;
//				}
//				//textos[textos.length - s1].value = total;
//				//total = 0;
//				txtTotal.value = total;
//				sum[t - 2] += num;
//				}
//			}
//		}
//	}

//El que mas se acerca a lo que necesitamos
 /****************************************************************/
// 		i = 0;
//		i = i +1;
//		j = 1;
//		j = j +1;
//		
//		
//		var v1 = document.getElementById("txtTota"+i).value;

//		alert("Valor"+v1);
//
//		var v2 = document.getElementById("txtTota"+j).value;
//		alert("Valor"+v2);
//
//		
//		var subtotal = (parseInt(v1+i) + parseInt(v2+j));
//		subtotal = parseInt(subtotal);
//		
//		document.getElementById("subTotal").value = subtotal
 